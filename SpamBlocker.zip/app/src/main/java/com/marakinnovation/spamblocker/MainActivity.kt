package com.marakinnovation.spamblocker

import android.Manifest
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.telecom.TelecomManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var db: BlocklistDbHelper
    private lateinit var prefs: SettingsPrefs
    private lateinit var listAdapter: ArrayAdapter<String>

    private val REQUIRED_PERMISSIONS = arrayOf(
        Manifest.permission.READ_PHONE_STATE,
        Manifest.permission.READ_CALL_LOG,
        Manifest.permission.READ_CONTACTS,
        Manifest.permission.ANSWER_PHONE_CALLS
    )

    private val roleRequestLauncher =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()) {
            updateStatusText()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        db = BlocklistDbHelper(this)
        prefs = SettingsPrefs(this)

        requestNeededPermissions()

        val statusText = findViewById<TextView>(R.id.statusText)
        val btnSetDefault = findViewById<Button>(R.id.btnSetDefault)
        val switchBlockUnknown = findViewById<Switch>(R.id.switchBlockUnknown)
        val inputNumber = findViewById<EditText>(R.id.inputNumber)
        val btnAddNumber = findViewById<Button>(R.id.btnAddNumber)
        val listView = findViewById<ListView>(R.id.blockedList)

        switchBlockUnknown.isChecked = prefs.isBlockUnknownEnabled()
        switchBlockUnknown.setOnCheckedChangeListener { _, isChecked ->
            prefs.setBlockUnknownEnabled(isChecked)
        }

        btnSetDefault.setOnClickListener { requestDefaultCallScreeningRole() }

        listAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, db.getAllBlocked())
        listView.adapter = listAdapter

        listView.setOnItemClickListener { _, _, position, _ ->
            val number = listAdapter.getItem(position) ?: return@setOnItemClickListener
            AlertDialog(this, number) {
                db.removeNumber(number)
                refreshList()
            }.show()
        }

        btnAddNumber.setOnClickListener {
            val number = inputNumber.text.toString().trim()
            if (number.isNotEmpty()) {
                db.addNumber(number)
                inputNumber.text.clear()
                refreshList()
            } else {
                Toast.makeText(this, "Enter a number first", Toast.LENGTH_SHORT).show()
            }
        }

        updateStatusText()
    }

    override fun onResume() {
        super.onResume()
        updateStatusText()
    }

    private fun refreshList() {
        listAdapter.clear()
        listAdapter.addAll(db.getAllBlocked())
        listAdapter.notifyDataSetChanged()
    }

    private fun requestNeededPermissions() {
        val missing = REQUIRED_PERMISSIONS.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), 100)
        }
    }

    /** This is the step Android requires: the user must explicitly approve
     *  this app taking over call screening. It cannot be done silently. */
    private fun requestDefaultCallScreeningRole() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = getSystemService(RoleManager::class.java)
            if (roleManager != null && roleManager.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING)) {
                if (!roleManager.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)) {
                    val intent = roleManager.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING)
                    roleRequestLauncher.launch(intent)
                } else {
                    Toast.makeText(this, "Already set as default", Toast.LENGTH_SHORT).show()
                }
            }
        } else {
            // Fallback for older devices: open the default apps settings screen.
            val intent = Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER)
            startActivity(intent)
        }
    }

    private fun updateStatusText() {
        val statusText = findViewById<TextView>(R.id.statusText)
        var isDefault = false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = getSystemService(RoleManager::class.java)
            isDefault = roleManager?.isRoleHeld(RoleManager.ROLE_CALL_SCREENING) == true
        }
        if (isDefault) {
            statusText.text = "Active — set as default call-screening app"
            statusText.setTextColor(0xFF2E7D32.toInt())
        } else {
            statusText.text = "Not active — tap below to enable auto-blocking"
            statusText.setTextColor(0xFFCC0000.toInt())
        }
    }
}

/** Minimal confirm dialog to remove a number from the blocklist. */
@Suppress("FunctionName")
fun AlertDialog(context: android.content.Context, number: String, onConfirm: () -> Unit): android.app.AlertDialog {
    return android.app.AlertDialog.Builder(context)
        .setTitle("Remove from blocklist?")
        .setMessage(number)
        .setPositiveButton("Remove") { _, _ -> onConfirm() }
        .setNegativeButton("Cancel", null)
        .create()
}
