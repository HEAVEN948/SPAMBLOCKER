package com.marakinnovation.spamblocker

import android.content.Context

class SettingsPrefs(context: Context) {
    private val prefs = context.getSharedPreferences("spam_blocker_prefs", Context.MODE_PRIVATE)

    fun isBlockUnknownEnabled(): Boolean =
        prefs.getBoolean(KEY_BLOCK_UNKNOWN, true) // on by default per user's request

    fun setBlockUnknownEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_BLOCK_UNKNOWN, enabled).apply()
    }

    companion object {
        private const val KEY_BLOCK_UNKNOWN = "block_unknown_enabled"
    }
}
