package com.marakinnovation.spamblocker

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/**
 * Stores the manual blocklist (numbers the user explicitly added)
 * plus a simple call log of what was blocked and why.
 */
class BlocklistDbHelper(context: Context) :
    SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {

    companion object {
        private const val DB_NAME = "spam_blocker.db"
        private const val DB_VERSION = 1

        const val TABLE_BLOCKLIST = "blocklist"
        const val TABLE_BLOCKED_LOG = "blocked_log"

        const val COL_ID = "_id"
        const val COL_NUMBER = "number"
        const val COL_ADDED_AT = "added_at"
        const val COL_REASON = "reason"
        const val COL_TIMESTAMP = "timestamp"
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE $TABLE_BLOCKLIST (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_NUMBER TEXT UNIQUE NOT NULL,
                $COL_ADDED_AT INTEGER NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE $TABLE_BLOCKED_LOG (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_NUMBER TEXT NOT NULL,
                $COL_REASON TEXT NOT NULL,
                $COL_TIMESTAMP INTEGER NOT NULL
            )
            """.trimIndent()
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_BLOCKLIST")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_BLOCKED_LOG")
        onCreate(db)
    }

    fun addNumber(number: String): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COL_NUMBER, normalize(number))
            put(COL_ADDED_AT, System.currentTimeMillis())
        }
        val result = db.insertWithOnConflict(
            TABLE_BLOCKLIST, null, values, SQLiteDatabase.CONFLICT_IGNORE
        )
        return result != -1L
    }

    fun removeNumber(number: String) {
        val db = writableDatabase
        db.delete(TABLE_BLOCKLIST, "$COL_NUMBER = ?", arrayOf(normalize(number)))
    }

    fun isBlocked(number: String): Boolean {
        val db = readableDatabase
        val cursor = db.query(
            TABLE_BLOCKLIST, arrayOf(COL_ID), "$COL_NUMBER = ?",
            arrayOf(normalize(number)), null, null, null
        )
        val found = cursor.count > 0
        cursor.close()
        return found
    }

    fun getAllBlocked(): List<String> {
        val list = mutableListOf<String>()
        val db = readableDatabase
        val cursor = db.query(
            TABLE_BLOCKLIST, arrayOf(COL_NUMBER), null, null, null, null,
            "$COL_ADDED_AT DESC"
        )
        while (cursor.moveToNext()) {
            list.add(cursor.getString(cursor.getColumnIndexOrThrow(COL_NUMBER)))
        }
        cursor.close()
        return list
    }

    fun logBlockedCall(number: String, reason: String) {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COL_NUMBER, number)
            put(COL_REASON, reason)
            put(COL_TIMESTAMP, System.currentTimeMillis())
        }
        db.insert(TABLE_BLOCKED_LOG, null, values)
    }

    fun getRecentBlockedLog(limit: Int = 50): List<Triple<String, String, Long>> {
        val list = mutableListOf<Triple<String, String, Long>>()
        val db = readableDatabase
        val cursor = db.query(
            TABLE_BLOCKED_LOG,
            arrayOf(COL_NUMBER, COL_REASON, COL_TIMESTAMP),
            null, null, null, null,
            "$COL_TIMESTAMP DESC",
            limit.toString()
        )
        while (cursor.moveToNext()) {
            list.add(
                Triple(
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_NUMBER)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_REASON)),
                    cursor.getLong(cursor.getColumnIndexOrThrow(COL_TIMESTAMP))
                )
            )
        }
        cursor.close()
        return list
    }

    /** Strips spaces/dashes so "+91 98765-43210" and "9876543210" match consistently. */
    fun normalize(number: String): String {
        return number.replace(Regex("[^0-9+]"), "")
    }
}
