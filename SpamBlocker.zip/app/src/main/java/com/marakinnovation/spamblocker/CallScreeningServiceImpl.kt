package com.marakinnovation.spamblocker

import android.content.ContentResolver
import android.provider.ContactsContract
import android.telecom.Call
import android.telecom.CallScreeningService
import android.util.Log

/**
 * Android calls onScreenCall() for every incoming call BEFORE the phone
 * rings. We inspect the number here and tell the OS whether to let it
 * through, reject it silently, or reject + skip the call log/notification.
 *
 * This only becomes active once the user sets this app as the default
 * "Caller ID & Spam" app under Settings > Apps > Default apps.
 */
class CallScreeningServiceImpl : CallScreeningService() {

    companion object {
        private const val TAG = "SpamBlocker"
    }

    override fun onScreenCall(callDetails: Call.Details) {
        val rawNumber = callDetails.handle?.schemeSpecificPart ?: run {
            // No number at all (e.g. some VoIP edge case) — let it ring,
            // we can't evaluate what we can't see.
            respondAllow(callDetails)
            return
        }

        val db = BlocklistDbHelper(applicationContext)
        val prefs = SettingsPrefs(applicationContext)

        // 1. Manual blocklist always wins
        if (db.isBlocked(rawNumber)) {
            Log.d(TAG, "Blocked (manual list): $rawNumber")
            db.logBlockedCall(rawNumber, "Manual blocklist")
            respondReject(callDetails)
            return
        }

        // 2. If "block unknown / non-contact" is enabled, reject anything
        //    not saved in the phone's Contacts app.
        if (prefs.isBlockUnknownEnabled()) {
            val isContact = isNumberInContacts(contentResolver, rawNumber)
            if (!isContact) {
                Log.d(TAG, "Blocked (not a contact): $rawNumber")
                db.logBlockedCall(rawNumber, "Unknown / not a contact")
                respondReject(callDetails)
                return
            }
        }

        // Otherwise, let it ring normally.
        respondAllow(callDetails)
    }

    private fun respondAllow(callDetails: Call.Details) {
        val response = CallResponse.Builder()
            .setDisallowCall(false)
            .setRejectCall(false)
            .setSkipCallLog(false)
            .setSkipNotification(false)
            .build()
        respondToCall(callDetails, response)
    }

    private fun respondReject(callDetails: Call.Details) {
        val response = CallResponse.Builder()
            .setDisallowCall(true)
            .setRejectCall(true)
            .setSkipCallLog(false)      // keep it in the log so the user can review/unblock
            .setSkipNotification(true)  // but don't show a missed-call notification for spam
            .build()
        respondToCall(callDetails, response)
    }

    private fun isNumberInContacts(resolver: ContentResolver, number: String): Boolean {
        val uri = android.net.Uri.withAppendedPath(
            ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
            android.net.Uri.encode(number)
        )
        val cursor = resolver.query(
            uri,
            arrayOf(ContactsContract.PhoneLookup._ID),
            null, null, null
        )
        val found = (cursor?.count ?: 0) > 0
        cursor?.close()
        return found
    }
}
