# Spam Blocker (Marak Innovation)

Native Android app that auto-rejects calls before they ring, using Android's
`CallScreeningService` API.

## What it does
- **Manual blocklist**: numbers you add are rejected automatically, every time.
- **Block unknown / non-contact**: toggle on by default — any number not saved
  in your phone's Contacts app is rejected automatically, no per-call action needed.
- Blocked calls are silently rejected (no ring, no notification), but stay in
  the call log so you can review and unblock a number if needed.

## How to build
1. Open this folder (`SpamBlocker/`) in Android Studio (Giraffe or newer).
2. Let Gradle sync — it will pull the dependencies listed in `app/build.gradle`.
3. Run on a device or emulator with **Android 10 (API 29) or higher** —
   `CallScreeningService` doesn't exist on older versions.
4. On first launch, grant the requested permissions (Phone, Call Log, Contacts).
5. Tap **"Set as Default Call Screening App"** — Android will show a system
   dialog asking you to confirm. This step is required by Android and can't
   be skipped or automated; only the user can grant it.
6. Once granted, blocking is fully automatic in the background — no app
   interaction needed per call.

## Notes
- Works for regular cellular calls only (not WhatsApp/VoIP calls — those
  aren't routed through the Telecom framework this API hooks into).
- Only one app can hold the call-screening role at a time. Setting this app
  as default will replace whatever was previously handling it (e.g. Truecaller,
  if installed).
- To add spam numbers in bulk instead of one at a time, you could later wire
  the `BlocklistDbHelper.addNumber()` call up to a CSV import — not included
  here, happy to add it if useful.

## Project structure
```
app/src/main/java/com/marakinnovation/spamblocker/
  MainActivity.kt              - UI: permissions, default-app request, blocklist management
  CallScreeningServiceImpl.kt  - the core interceptor that runs per incoming call
  BlocklistDbHelper.kt         - SQLite storage for manual blocklist + block log
  SettingsPrefs.kt             - stores the "block unknown" toggle state
```
